// routes/projects.js
import express from "express";
import Project from "../models/Project.js";
import auth from "../middleware/auth.js";

const router = express.Router();

// Create new project
router.post("/", auth, async (req, res) => {
  try {
    const { title, files, entry } = req.body;
    const proj = new Project({ owner: req.user.id, title, files, entry });
    await proj.save();
    res.status(201).json(proj);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// Get projects for the logged in user
router.get("/", auth, async (req, res) => {
  try {
    const list = await Project.find({ owner: req.user.id }).sort({ updatedAt: -1 });
    res.json(list);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// Get one project
router.get("/:id", auth, async (req, res) => {
  try {
    const proj = await Project.findById(req.params.id);
    if(!proj) return res.status(404).json({ message: "Not found" });
    if(proj.owner.toString() !== req.user.id) return res.status(403).json({ message: "Forbidden" });
    res.json(proj);
  } catch(err) {
    res.status(500).json({ message: "Server error" });
  }
});

// Update project (replace files/title etc.)
router.put("/:id", auth, async (req, res) => {
  try {
    const proj = await Project.findById(req.params.id);
    if(!proj) return res.status(404).json({ message: "Not found" });
    if(proj.owner.toString() !== req.user.id) return res.status(403).json({ message: "Forbidden" });

    const { title, files, entry } = req.body;
    if(title !== undefined) proj.title = title;
    if(files !== undefined) proj.files = files;
    if(entry !== undefined) proj.entry = entry;
    await proj.save();
    res.json(proj);
  } catch(err) {
    res.status(500).json({ message: "Server error" });
  }
});

// Delete project
router.delete("/:id", auth, async (req, res) => {
  try {
    const proj = await Project.findById(req.params.id);
    if(!proj) return res.status(404).json({ message: "Not found" });
    if(proj.owner.toString() !== req.user.id) return res.status(403).json({ message: "Forbidden" });
    await proj.delete();
    res.json({ message: "Deleted" });
  } catch(err) {
    res.status(500).json({ message: "Server error" });
  }
});

export default router;
