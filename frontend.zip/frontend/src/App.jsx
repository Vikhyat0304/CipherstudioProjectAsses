import React from "react";
import { Routes, Route } from "react-router-dom";
import ProjectProvider from "./contexts/ProjectContext";
import IDE from "./components/IDE";
import Login from "./pages/Login";
import Register from "./pages/Register";

export default function App() {
  return (
    <ProjectProvider>
      <Routes>
        <Route path="/" element={<IDE />} />              {/* Main IDE page */}
        <Route path="/login" element={<Login />} />      {/* Login page */}
        <Route path="/register" element={<Register />} />{/* Register page */}
      </Routes>
    </ProjectProvider>
  );
}
