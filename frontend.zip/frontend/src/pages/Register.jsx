// src/pages/Register.jsx
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../contexts/AuthContext";

export default function Register() {
  const authContext = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  if (!authContext) return null;
  const { login } = authContext;

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    if (!form.name || !form.email || !form.password) {
      setError("All fields are required");
      return;
    }

    try {
      setLoading(true);
      const res = await api.post("/auth/register", form);
      const { token, user } = res.data;

      if (!token) throw new Error("Token not provided by server");

      login(user, token);
      alert("Account created successfully!");
      navigate("/");
    } catch (err) {
      const msg =
        err.response?.data?.message ||
        err.response?.data?.msg ||
        err.message ||
        "Registration failed";
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="d-flex justify-content-center align-items-center vh-100"
      style={{
        background: "radial-gradient(circle at top left, #568d4fff, #103b86ff)",
        fontFamily: "'Segoe UI', Tahoma, sans-serif",
        overflow: "hidden",
      }}
    >
      {/* Neon Floating Card */}
      <form
        onSubmit={handleSubmit}
        className="p-5 rounded-4"
        style={{
          width: 420,
          background: "rgba(22, 112, 88, 0.58)",
          boxShadow:
            "0 0 20px rgba(223, 174, 174, 0.77), 0 10px 30px rgba(0,0,0,0.5), 0 0 40px rgba(255,105,180,0.3)",
          border: "2px solid rgba(255,105,180,0.6)",
          animation: "float 6s ease-in-out infinite",
          color: "#ede2e2ff",
          position: "relative",
        }}
      >
        <h2
           className="text-center mb-5 fw-bold"
  style={{
    fontSize: "2.2rem",
    background: "linear-gradient(135deg, #b47a4bff, #f7c1e0, #a17fa2)",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
    textShadow: "1px 1px 4px rgba(0,0,0,0.25), 0 0 12px rgba(255,182,193,0.4)",
  }}
>
          Create Account
        </h2>

        {error && (
          <div
            className="alert alert-danger py-2 shadow-sm"
            style={{ background: "#ff4d4f", color: "#fff" }}
          >
            {error}
          </div>
        )}

        <div className="mb-4">
          <input
            name="name"
            value={form.name}
            onChange={handleChange}
            type="text"
            placeholder="Full Name"
            className="form-control form-control-lg rounded-pill"
            required
            style={{
              background: "rgba(86, 181, 173, 0.75)",
              border: "1px solid rgba(255,105,180,0.5)",
              color: "#fff",
              padding: "0.75rem 1.25rem",
              fontSize: "1rem",
              boxShadow: "0 0 10px rgba(255,105,180,0.2) inset",
              transition: "0.3s",
            }}
          />
        </div>

        <div className="mb-4">
          <input
            name="email"
            value={form.email}
            onChange={handleChange}
            type="email"
            placeholder="Email Address"
            className="form-control form-control-lg rounded-pill"
            required
            style={{
              background: "rgba(52, 161, 136, 0.82)",
              border: "1px solid rgba(255,105,180,0.5)",
              color: "#b18686ff",
              padding: "0.75rem 1.25rem",
              fontSize: "1rem",
              boxShadow: "0 0 10px rgba(255,105,180,0.2) inset",
              transition: "0.3s",
            }}
          />
        </div>

        <div className="mb-4">
          <input
            name="password"
            value={form.password}
            onChange={handleChange}
            type="password"
            placeholder="Password"
            className="form-control form-control-lg rounded-pill"
            required
            style={{
              background: "rgba(52, 161, 136, 0.82)",
              border: "1px solid rgba(255,105,180,0.5)",
              color: "#58cf82ff",
              padding: "0.75rem 1.25rem",
              fontSize: "1rem",
              boxShadow: "0 0 10px rgba(255,105,180,0.2) inset",
              transition: "0.3s",
            }}
          />
        </div>

        <button
          type="submit"
          className="btn w-100 rounded-pill fw-bold shadow"
          disabled={loading}
          style={{
            background:
              "linear-gradient(90deg, #d1451bff, #af5757ff, #e7dbe0ff)",
            color: "#fff",
            padding: "0.75rem",
            fontSize: "1rem",
            border: "none",
            boxShadow:
              "0 4px 15px rgba(255,105,180,0.4), 0 0 20px rgba(255,105,180,0.3) inset",
            transition: "0.3s",
          }}
          onMouseOver={(e) =>
            (e.currentTarget.style.filter = "brightness(1.2)")
          }
          onMouseOut={(e) => (e.currentTarget.style.filter = "brightness(1)")}
        >
          {loading ? "Creating..." : "Register"}
        </button>

        <div className="text-center mt-3">
          <small style={{ color: "#b5a5a5ff" }}>
            Already have an account?{" "}
            <Link
              to="/login"
              style={{ color: "#ff69b4", fontWeight: "600" }}
            >
              Login
            </Link>
          </small>
        </div>

        <style>{`
          @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
          }
          input:focus {
            border-color: #ff69b4 !important;
            box-shadow: 0 0 15px rgba(255,105,180,0.5) inset;
            background: rgba(255,255,255,0.1);
            color: #fff;
          }
        `}</style>
      </form>
    </div>
  );
}
