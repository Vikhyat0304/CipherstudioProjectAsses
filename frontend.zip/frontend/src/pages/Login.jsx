// src/pages/Login.jsx
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../contexts/AuthContext";

export default function Login() {
  const authContext = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  if (!authContext) {
    return (
      <div className="text-center mt-5">
        <p style={{ color: "red" }}>
          AuthProvider is missing. Wrap your App with &lt;AuthProvider&gt;.
        </p>
      </div>
    );
  }

  const { login } = authContext;

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    if (!form.email || !form.password) {
      setError("Please enter both email and password");
      return;
    }

    try {
      setLoading(true);
      const res = await api.post("/auth/login", form);
      const { token, user } = res.data;

      if (!token) throw new Error("Server did not provide a token");

      login(user || { email: form.email }, token);
      navigate("/"); // Navigate to IDE or dashboard
    } catch (err) {
      const msg =
        err.response?.data?.message ||
        err.response?.data?.msg ||
        err.message ||
        "Login failed";
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="d-flex justify-content-center align-items-center vh-100"
      style={{
        fontFamily: "'Segoe UI', Tahoma, sans-serif",
        background: "linear-gradient(-45deg, #ff9a9e, #fad0c4, #a18cd1, #fbc2eb)",
        backgroundSize: "400% 400%",
        animation: "gradientBG 15s ease infinite",
      }}
    >
      <style>
        {`
          @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
          }
        `}
      </style>

      <form
        onSubmit={handleSubmit}
        className="p-5 rounded-4 shadow-lg"
        style={{
          width: 380,
          backdropFilter: "blur(12px)",
          backgroundColor: "rgba(255,255,255,0.85)",
          border: "1px solid rgba(255,255,255,0.3)",
        }}
      >
        <h3
          className="text-center mb-4 fw-bold"
          style={{
            background: "linear-gradient(90deg, #ff8a00, #e52e71, #9b00ff)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          Welcome Back
        </h3>

        {error && (
          <div className="alert alert-danger py-2 small shadow-sm">{error}</div>
        )}

        <div className="mb-3">
          <label className="form-label fw-semibold small">Email</label>
          <input
            name="email"
            value={form.email}
            onChange={handleChange}
            type="email"
            className="form-control form-control-sm rounded-pill shadow-sm"
            placeholder="you@company.com"
            required
            style={{ border: "1px solid #ddd" }}
          />
        </div>

        <div className="mb-4">
          <label className="form-label fw-semibold small">Password</label>
          <input
            name="password"
            value={form.password}
            onChange={handleChange}
            type="password"
            className="form-control form-control-sm rounded-pill shadow-sm"
            placeholder="Your password"
            required
            style={{ border: "1px solid #ddd" }}
          />
        </div>

        <button
          type="submit"
          className="btn btn-gradient w-100 rounded-pill fw-bold shadow-sm"
          disabled={loading}
          style={{
            background: "linear-gradient(90deg, #ff8a00, #e52e71, #9b00ff)",
            color: "#fff",
            border: "none",
            padding: "0.5rem",
            transition: "0.3s",
          }}
          onMouseOver={(e) =>
            (e.currentTarget.style.filter = "brightness(1.1)")
          }
          onMouseOut={(e) => (e.currentTarget.style.filter = "brightness(1)")}
        >
          {loading ? "Signing in..." : "Sign In"}
        </button>

        <div className="text-center mt-3">
          <small>
            Don't have an account?{" "}
            <Link
              to="/register"
              style={{
                textDecoration: "none",
                fontWeight: "600",
                color: "#e52e71",
              }}
            >
              Register
            </Link>
          </small>
        </div>
      </form>
    </div>
  );
}
