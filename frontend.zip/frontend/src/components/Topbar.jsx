// src/components/Topbar.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // ✅ for navigation
import { useProject } from "../contexts/ProjectContext";
import "bootstrap/dist/css/bootstrap.min.css";

export default function Topbar() {
  const navigate = useNavigate(); // ✅ must be inside Router

  // ✅ Get project context safely
  const projectContext = useProject();
  const project = projectContext?.project || {
    title: "CipherStudio",
    settings: { theme: "light", autosave: false },
  };
  const saveToLocal = projectContext?.saveToLocal || (() => "1");
  const loadFromLocal = projectContext?.loadFromLocal || (() => true);
  const exportProjectJSON = projectContext?.exportProjectJSON || (() => "{}");
  const toggleTheme = projectContext?.toggleTheme || (() => {});
  const toggleAutosave = projectContext?.toggleAutosave || (() => {});

  const [loadId, setLoadId] = useState("");

  const handleSave = () => {
    const id = saveToLocal();
    alert(`Project saved locally (ID: ${id})`);
  };

  const handleLoad = () => {
    if (!loadId) return alert("Enter project ID");
    const ok = loadFromLocal(loadId);
    ok ? alert("Project loaded") : alert("Project not found");
  };

  const handleExport = () => {
    const data = exportProjectJSON();
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${project.title || "cipherstudio"}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <nav
      className="navbar navbar-expand-lg shadow-sm rounded px-3"
      style={{
        backgroundColor: project.settings.theme === "dark" ? "#1e1e2f" : "#f8f9fa",
      }}
    >
      {/* Project Title with Gradient */}
      <span
        className="navbar-brand fw-bold me-3"
        style={{
          fontSize: "1.5rem",
          background: "linear-gradient(90deg, #ff8a00, #e52e71, #9b00ff)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          textShadow: "1px 1px 3px rgba(0,0,0,0.2)",
        }}
      >
        {project.title}
      </span>

      <div className="ms-auto d-flex align-items-center flex-wrap" style={{ gap: "0.9rem" }}>
        {/* Theme Switch */}
        <button
          className="btn btn-outline-primary btn-sm rounded-pill"
          onClick={toggleTheme}
          title="Toggle Theme"
        >
          {project.settings.theme === "light" ? "🌙 Dark" : "☀️ Light"}
        </button>

        {/* Autosave Toggle */}
        <button
          className="btn btn-outline-success btn-sm rounded-pill"
          onClick={toggleAutosave}
          title="Toggle Autosave"
        >
          Autosave: {project.settings.autosave ? "ON" : "OFF"}
        </button>

        {/* Save Project */}
        <button
          className="btn btn-primary btn-sm rounded-pill"
          onClick={handleSave}
          title="Save Project Locally"
        >
          💾 Save
        </button>

        {/* Load Project */}
        <div className="input-group input-group-sm" style={{ width: 120 }}>
          <input
            type="text"
            className="form-control rounded-start"
            placeholder="Project ID"
            value={loadId}
            onChange={(e) => setLoadId(e.target.value)}
          />
          <button
            className="btn btn-warning rounded-end"
            onClick={handleLoad}
            title="Load Project"
          >
            🔄
          </button>
        </div>

        {/* Export JSON */}
        <button
          className="btn btn-secondary btn-sm rounded-pill"
          onClick={handleExport}
          title="Export Project JSON"
        >
          📦 Export
        </button>

        {/* Login/Register */}
        <button
          className="btn btn-outline-dark btn-sm rounded-pill"
          onClick={() => navigate("/login")} // ✅ navigate to Login page
        >
          Login
        </button>
        <button
          className="btn btn-dark btn-sm rounded-pill"
          onClick={() => navigate("/register")} // ✅ navigate to Register page
        >
          Register
        </button>
      </div>
    </nav>
  );
}
