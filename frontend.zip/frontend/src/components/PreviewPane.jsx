import React from "react";
import { SandpackProvider, SandpackPreview } from "@codesandbox/sandpack-react";
import { useProject } from "../contexts/ProjectContext";

export default function PreviewPane() {
  const { project } = useProject();
  const isDark = project.settings.theme === "dark";

  const filesObject = project.files.reduce((acc, f) => {
    acc[f.path] = f.content;
    return acc;
  }, {});

  const containerStyle = {
    flex: 1,
    margin: 12,
    borderRadius: "12px",
    overflow: "hidden",
    boxShadow: "0 4px 20px rgba(0,0,0,0.2)",
    border: isDark ? "1px solid #444" : "1px solid #ddd",
    backgroundColor: isDark ? "#2b2b3a" : "#fff",
    transition: "all 0.3s ease",
  };

  return (
    <SandpackProvider template="react" files={filesObject} options={{ entry: project.entry }}>
      <div style={containerStyle}>
        <SandpackPreview 
          style={{
            height: "100%",
            width: "100%",
            borderRadius: "12px",
          }}
        />
      </div>
    </SandpackProvider>
  );
}
