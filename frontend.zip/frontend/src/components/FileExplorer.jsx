import React, { useState } from "react";
import { useProject } from "../contexts/ProjectContext";
import "bootstrap/dist/css/bootstrap.min.css";

export default function FileExplorer({ onSelect, selectedId }) {
  const { project, createFile, deleteFile, renameFile } = useProject();
  const [newPath, setNewPath] = useState("");
  const [renamingId, setRenamingId] = useState("");
  const [renameValue, setRenameValue] = useState("");

  const handleCreate = () => {
    if (!newPath) return alert("Enter file path like src/Hello.js");
    const nf = createFile(
      newPath,
      `export default function Hello(){ return <div>New file: ${newPath}</div> }`
    );
    setNewPath("");
    onSelect(nf.id);
  };

  const handleRename = (id) => {
    if (!renameValue) return alert("Enter new name");
    renameFile(id, renameValue);
    setRenamingId("");
  };

  // Theme colors object
  const themeColors = {
    light: { fileBg: "#fff", fileText: "#1e1e2f", hoverBg: "#f0f0f0", selectedBg: "#e9f5ff" },
    dark: { fileBg: "#2b2b3a", fileText: "#f5f5f5", hoverBg: "#3f3f55", selectedBg: "#3a3a4f" }
  };

  const { fileBg, fileText, hoverBg, selectedBg } = themeColors[project.settings.theme];

  return (
    <div
      className="p-3"
      style={{
        height: "100%",
        backgroundColor: fileBg,
        color: fileText,
        borderRight: project.settings.theme === "dark" ? "1px solid #444" : "1px solid #ddd",
        borderRadius: "0.5rem",
        fontFamily: "'Segoe UI', Roboto, sans-serif"
      }}
    >
      <h5 className="mb-3 fw-bold text-primary">{project.title}</h5>

      <div className="input-group mb-3">
        <input
          type="text"
          className="form-control form-control-sm"
          placeholder="src/Hello.js"
          value={newPath}
          onChange={(e) => setNewPath(e.target.value)}
        />
        <button className="btn btn-success btn-sm" onClick={handleCreate}>
          Create
        </button>
      </div>

      <div className="list-group" style={{ maxHeight: "calc(100% - 80px)", overflowY: "auto" }}>
        {project.files.map((f) => (
          <div
            key={f.id}
            className={`list-group-item d-flex justify-content-between align-items-center`}
            style={{
              backgroundColor: f.id === selectedId ? selectedBg : fileBg,
              color: fileText,
              cursor: "pointer",
              borderRadius: "0.5rem",
              marginBottom: "4px",
              transition: "all 0.2s ease-in-out"
            }}
            onClick={() => onSelect(f.id)}
            onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = hoverBg; }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = f.id === selectedId ? selectedBg : fileBg;
            }}
          >
            {renamingId === f.id ? (
              <>
                <input
                  type="text"
                  className="form-control form-control-sm me-2"
                  value={renameValue}
                  onChange={(e) => setRenameValue(e.target.value)}
                />
                <button className="btn btn-primary btn-sm me-1" onClick={() => handleRename(f.id)}>✔</button>
                <button className="btn btn-secondary btn-sm" onClick={() => setRenamingId("")}>✖</button>
              </>
            ) : (
              <>
                <div style={{ flex: 1 }}>{f.path}</div>
                <div className="d-flex gap-1">
                  <button
                    className="btn btn-warning btn-sm"
                    onClick={() => {
                      setRenamingId(f.id);
                      setRenameValue(f.path);
                    }}
                  >
                    Rename
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => { if (window.confirm("Delete file?")) deleteFile(f.id); }}
                  >
                    Delete
                  </button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
