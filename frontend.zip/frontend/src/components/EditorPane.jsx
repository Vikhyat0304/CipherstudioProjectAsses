import React, { useMemo, useState } from "react";
import { Sandpack } from "@codesandbox/sandpack-react";
import { useProject } from "../contexts/ProjectContext";
import "bootstrap/dist/css/bootstrap.min.css";

export default function EditorPane({ selectedFileId }) {
  const { project } = useProject();
  const [editorHeight, setEditorHeight] = useState(550);

  const sandpackFiles = useMemo(() => {
    const files = {};
    project.files.forEach(f => (files[f.path] = f.content));
    return files;
  }, [project.files]);

  const selected = project.files.find(f => f.id === selectedFileId) || project.files[0];

  // Theme Colors
  const isDark = project.settings.theme === "dark";
  const headerStyle = {
    padding: "8px 12px",
    borderRadius: "0.5rem",
    backgroundColor: isDark ? "#3a3a4f" : "#f8f9fa",
    fontWeight: 600,
    color: isDark ? "#f5f5f5" : "#1e1e2f",
    border: isDark ? "1px solid #444" : "1px solid #ddd",
    boxShadow: "0 2px 5px rgba(0,0,0,0.05)",
    marginBottom: "8px"
  };

  const containerStyle = {
    flex: 1,
    minHeight: 0,
    borderRadius: "0.5rem",
    overflow: "hidden",
    boxShadow: "0 3px 15px rgba(0,0,0,0.1)",
    border: isDark ? "1px solid #555" : "1px solid #ddd"
  };

  return (
    <div className="d-flex flex-column h-100 p-2" style={{ gap: "8px" }}>
      {/* File Header */}
      <div style={headerStyle}>
        {selected ? selected.path : "Select a file to edit"}
      </div>

      {/* Sandpack Editor */}
      <div style={containerStyle}>
        <Sandpack
          template="react"
          files={sandpackFiles}
          entry={project.entry}
          options={{
            showLineNumbers: true,
            editorHeight,
            showTabs: true,
            showNavigator: true,
            wrapContent: true,
            editorTheme: isDark ? "dark" : "light",
          }}
        />
      </div>
    </div>
  );
}
