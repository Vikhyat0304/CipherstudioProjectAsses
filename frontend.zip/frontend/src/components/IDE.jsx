import React, { useState } from "react";
import { useProject } from "../contexts/ProjectContext";
import FileExplorer from "./FileExplorer";
import EditorPane from "./EditorPane";
import PreviewPane from "./PreviewPane";
import Topbar from "./Topbar";

export default function IDE() {
  const { project } = useProject();
  const [selectedFileId, setSelectedFileId] = useState(null);

  const isDark = project.settings.theme === "dark";
  const themeStyles = {
    backgroundColor: isDark ? "#1e1e2f" : "#f5f5f5",
    color: isDark ? "#f5f5f5" : "#1e1e2f",
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        ...themeStyles
      }}
    >
      {/* Topbar */}
      <div
        style={{
          flex: "0 0 70px",
          padding: "0 20px",
          borderBottom: isDark ? "1px solid #333" : "1px solid #ccc",
          boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
          display: "flex",
          alignItems: "center",
          zIndex: 10,
          backgroundColor: themeStyles.backgroundColor,
        }}
      >
        <Topbar />
      </div>

      {/* IDE Body */}
      <div
        style={{
          flex: 1,
          display: "flex",
          minHeight: 0,
          overflow: "hidden",
        }}
      >
        {/* File Explorer */}
        <div
          style={{
            flex: "0 0 360px",
            borderRight: isDark ? "1px solid #333" : "1px solid #ccc",
            overflowY: "auto",
            padding: 12,
            transition: "all 0.3s ease",
            backgroundColor: isDark ? "#252535" : "#fff",
            borderRadius: "0 0 0 0.5rem",
          }}
        >
          <FileExplorer onSelect={setSelectedFileId} selectedId={selectedFileId} />
        </div>

        {/* Editor */}
        <div
          style={{
            flex: 1,
            minWidth: 0,
            display: "flex",
            flexDirection: "column",
            borderRight: isDark ? "1px solid #333" : "1px solid #ccc",
            backgroundColor: isDark ? "#1f1f30" : "#fefefe",
            borderRadius: "0",
          }}
        >
          <EditorPane selectedFileId={selectedFileId} />
        </div>

        {/* Preview */}
        <div
          style={{
            flex: "0 0 480px",
            backgroundColor: isDark ? "#1f1f30" : "#fafafa",
            overflow: "hidden",
            display: "flex",
            flexDirection: "column",
            borderLeft: isDark ? "1px solid #333" : "1px solid #ccc",
            borderRadius: "0 0.5rem 0.5rem 0",
          }}
        >
          <PreviewPane />
        </div>
      </div>
    </div>
  );
}
