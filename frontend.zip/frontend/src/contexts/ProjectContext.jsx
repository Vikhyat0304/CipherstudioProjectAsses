import React, { createContext, useContext, useEffect, useState } from "react";
import { v4 as uuidv4 } from "uuid";

const ProjectContext = createContext();
export function useProject(){ return useContext(ProjectContext); }

// Default files
const defaultFiles = [
  {
    id: "file-package",
    path: "package.json",
    content: JSON.stringify({
      name:"cipherstudio-project",
      version:"1.0.0",
      private:true,
      dependencies:{ react:"18.2.0", "react-dom":"18.2.0" }
    }, null, 2),
    type:"file"
  },
  { id:"file-html", path:"public/index.html", content:"<!doctype html><html><head><meta charset='utf-8'/></head><body><div id='root'></div></body></html>", type:"file" },
  { id:"file-index", path:"src/index.js", content:`import React from "react";\nimport { createRoot } from "react-dom/client";\nimport App from "./App";\ncreateRoot(document.getElementById("root")).render(<App/>);`, type:"file" },
  { id:"file-app", path:"src/App.js", content:`export default function App(){ return (<div style={{padding:20}}>Welcome to CipherStudio</div>); }`, type:"file" }
];

export default function ProjectProvider({ children }){
  const [project, setProject] = useState(()=>{
    const id = uuidv4();
    return {
      id,
      title:"MyCipherStudioProject",
      files: defaultFiles,
      entry:"src/index.js",
      settings:{ theme:"light", autosave:true }
    };
  });

  // Define dynamic theme colors
  const themeColors = {
    light: {
      background: "#ffffff",
      text: "#1e1e2f",
      fileBg: "#fefefe",
      fileText: "#1e1e2f",
      border: "#ccc"
    },
    dark: {
      background: "#1e1e2f",
      text: "#f5f5f5",
      fileBg: "#252535",
      fileText: "#f5f5f5",
      border: "#333"
    }
  };

  useEffect(()=>{
    if(project?.settings?.autosave){
      localStorage.setItem(`cipherstudio_project_${project.id}`, JSON.stringify(project));
    }
  },[project]);

  const createFile=(path,content="")=>{
    const newFile={id:uuidv4(), path, content, type:"file"};
    setProject(prev=>({...prev, files:[...prev.files,newFile]}));
    return newFile;
  };

  const updateFile=(fileId,newContent)=>{
    setProject(prev=>({...prev, files:prev.files.map(f=>f.id===fileId?{...f,content:newContent}:f)}));
  };

  const deleteFile=(fileId)=>{
    setProject(prev=>({...prev, files:prev.files.filter(f=>f.id!==fileId)}));
  };

  const renameFile=(fileId,newPath)=>{
    setProject(prev=>({...prev, files:prev.files.map(f=>f.id===fileId?{...f,path:newPath}:f)}));
  };

  const toggleTheme=()=>{
    setProject(prev=>({...prev, settings:{...prev.settings, theme: prev.settings.theme==="light"?"dark":"light"}}));
  };

  const toggleAutosave=()=>{
    setProject(prev=>({...prev, settings:{...prev.settings, autosave: !prev.settings.autosave}}));
  };

  const saveToLocal=(idOverride)=>{
    const id=idOverride||project.id;
    localStorage.setItem(`cipherstudio_project_${id}`,JSON.stringify({...project,id}));
    return id;
  };

  const loadFromLocal=(projectId)=>{
    const raw=localStorage.getItem(`cipherstudio_project_${projectId}`);
    if(!raw) return false;
    try{ setProject(JSON.parse(raw)); return true }catch(e){ return false }
  };

  const exportProjectJSON=()=>JSON.stringify(project,null,2);

  return (
    <ProjectContext.Provider value={{
      project,
      setProject,
      createFile,
      updateFile,
      deleteFile,
      renameFile,
      saveToLocal,
      loadFromLocal,
      exportProjectJSON,
      toggleTheme,
      toggleAutosave,
      themeColors // <-- added here for IDE components to use
    }}>
      {children}
    </ProjectContext.Provider>
  );
}
