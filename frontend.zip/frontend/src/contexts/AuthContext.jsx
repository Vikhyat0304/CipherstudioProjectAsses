// src/contexts/AuthContext.jsx
import React, { createContext, useContext, useEffect, useState } from "react";
import { attachToken } from "../api/axios";

const AuthContext = createContext();
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("cs_user")) || null;
    } catch { return null; }
  });
  const [token, setToken] = useState(() => localStorage.getItem("cs_token") || null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    attachToken(token);
    if (token) localStorage.setItem("cs_token", token);
    else localStorage.removeItem("cs_token");
  }, [token]);

  useEffect(() => {
    if (user) localStorage.setItem("cs_user", JSON.stringify(user));
    else localStorage.removeItem("cs_user");
  }, [user]);

  const login = (userObj, jwt) => {
    setUser(userObj);
    setToken(jwt);
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    attachToken(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, loading, setLoading }}>
      {children}
    </AuthContext.Provider>
  );
}
